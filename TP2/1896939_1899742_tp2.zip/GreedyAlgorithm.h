//
// Created by milen on 2021-11-08.
//

#ifndef TP2_GREEDYALGORITHM_H
#define TP2_GREEDYALGORITHM_H


#include "Graph.h"

class GreedyAlgorithm {
public:
    static void solve(Graph *graph);
};


#endif //TP2_GREEDYALGORITHM_H
