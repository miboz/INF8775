#!/bin/bash

./INF8775_tp2 "$@"